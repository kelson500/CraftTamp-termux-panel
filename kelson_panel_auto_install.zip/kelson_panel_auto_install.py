import os
import subprocess
import sys
import time

# Cores para terminal
R = "\033[31m"
G = "\033[32m"
Y = "\033[33m"
B = "\033[34m"
M = "\033[35m"
C = "\033[36m"
W = "\033[0m"

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def banner():
    print(f"""{G}
 _   __      _                                      
| | / /     | |                                     
| |/ /  ___ | |__    ___  _ __   ___  ___  ___    
|    \ / _ \| '_ \  / _ \| '_ \ / __|/ __|/ _ \   
| |\  \ (_) | |_) ||  __/| | | |\__ \\__ \  __/   
|_| \_\___/|_.__/  \___||_| |_|___/|___/\___|   
{W}
    """)

def run_cmd(cmd):
    try:
        subprocess.run(cmd, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"{R}Erro ao executar: {cmd}{W}")
        print(e)
        time.sleep(2)

def install_package(pkg):
    print(f"{Y}Instalando {pkg}...{W}")
    if os.path.exists('/data/data/com.termux/files/usr/bin/pkg'):
        # Termux
        run_cmd(f"pkg install -y {pkg}")
    else:
        # Linux padrão
        run_cmd(f"sudo apt-get install -y {pkg}")

def check_command(cmd):
    return subprocess.call(f"type {cmd}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def setup_environment():
    clear()
    print(f"{Y}Verificando e instalando dependências necessárias...{W}")

    packages = {
        "hydra": "hydra",
        "nmap": "nmap",
        "curl": "curl",
        "python3": "python3",
        "git": "git",
        "cmatrix": "cmatrix",
        "whois": "whois",
    }

    for cmd, pkg in packages.items():
        if not check_command(cmd):
            install_package(pkg)
        else:
            print(f"{G}{pkg} já instalado.{W}")

    # Clonar sqlmap se não existir
    if not os.path.isdir("sqlmap"):
        print(f"{Y}Clonando sqlmap...{W}")
        run_cmd("git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git")
    else:
        print(f"{G}Sqlmap já está clonado.{W}")

    # Clonar wordlist rockyou se não existir
    if not os.path.isfile("wordlist.txt"):
        print(f"{Y}Baixando wordlist rockyou...{W}")
        run_cmd("curl -Lo rockyou.txt.gz https://github.com/brannondorsey/naive-hashcat-rockyou/raw/master/rockyou.txt")
        run_cmd("gzip -d rockyou.txt.gz")
    else:
        print(f"{G}Wordlist já existe.{W}")

    print(f"{G}Ambiente pronto!{W}")
    time.sleep(2)

def brute_force():
    clear()
    print(f"{Y}--- Ataque Força Bruta (Hydra) ---{W}")
    target = input("Alvo (IP ou domínio): ").strip()
    service = input("Serviço (ex: ssh, ftp, http-get): ").strip()
    user = input("Usuário (login): ").strip()
    wordlist = input("Caminho para wordlist (ex: rockyou.txt): ").strip()

    # Verificar se wordlist existe
    if not os.path.isfile(wordlist):
        print(f"{R}Arquivo de wordlist não encontrado!{W}")
        time.sleep(2)
        return

    cmd = f"hydra -l {user} -P {wordlist} {service}://{target}"
    print(f"\nExecutando comando:\n{C}{cmd}{W}\n")
    input("Pressione Enter para iniciar...")

    try:
        subprocess.run(cmd, shell=True)
    except KeyboardInterrupt:
        print("\nInterrompido pelo usuário.")

def show_ip():
    clear()
    print(f"{Y}--- IP Público ---{W}")
    os.system("curl -s ifconfig.me")
    input("\nPressione Enter para voltar...")

def whois_lookup():
    clear()
    print(f"{Y}--- Whois ---{W}")
    domain = input("Domínio ou IP para consulta: ").strip()
    if domain:
        os.system(f"whois {domain}")
    else:
        print(f"{R}Entrada inválida!{W}")
    input("\nPressione Enter para voltar...")

def nmap_scan():
    clear()
    print(f"{Y}--- Nmap Scanner ---{W}")
    target = input("IP ou domínio alvo: ").strip()
    if target:
        os.system(f"nmap {target}")
    else:
        print(f"{R}Entrada inválida!{W}")
    input("\nPressione Enter para voltar...")

def sqlmap_scan():
    clear()
    print(f"{Y}--- SQL Injection (Sqlmap) ---{W}")
    url = input("URL alvo (ex: http://site.com/page.php?id=1): ").strip()
    if url:
        os.system(f"python3 sqlmap/sqlmap.py -u \"{url}\" --batch")
    else:
        print(f"{R}Entrada inválida!{W}")
    input("\nPressione Enter para voltar...")

def hash_identifier():
    clear()
    print(f"{Y}--- Hash-Identifier ---{W}")
    hash_value = input("Hash para identificar: ").strip()
    if hash_value:
        print("\nFerramenta online não disponível, use sites como https://hashes.com/en/tools/hash_identifier")
    else:
        print(f"{R}Entrada inválida!{W}")
    input("\nPressione Enter para voltar...")

def gen_password():
    clear()
    print(f"{Y}--- Gerar senha forte ---{W}")
    length = input("Tamanho da senha (ex: 16): ").strip()
    if length.isdigit():
        length = int(length)
        import secrets, string
        chars = string.ascii_letters + string.digits + string.punctuation
        pwd = ''.join(secrets.choice(chars) for _ in range(length))
        print(f"\nSenha gerada: {G}{pwd}{W}")
    else:
        print(f"{R}Entrada inválida!{W}")
    input("\nPressione Enter para voltar...")

def custom_banner():
    clear()
    print(f"{Y}--- Banner personalizado ---{W}")
    print(f"{G}Kelson @ CraftTamp - Sistema Hacker Ético{W}")
    input("\nPressione Enter para voltar...")

def toggle_cmatrix():
    clear()
    print(f"{Y}--- Toggle Matrix (cmatrix) ---{W}")
    import psutil
    cmatrix_running = False
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] == 'cmatrix':
            cmatrix_running = True
            proc.kill()
            print("Cmatrix parado.")
            break
    if not cmatrix_running:
        import subprocess
        subprocess.Popen(['cmatrix', '-C', 'green'])
        print("Cmatrix iniciado.")
    input("\nPressione Enter para voltar...")

def main():
    setup_environment()
    while True:
        clear()
        banner()
        print(f"""{Y}===== PAINEL HACKER ÉTICO (CraftTamp) ====={W}
{G}1.{W} Ataque Força Bruta (Hydra)
{G}2.{W} Ver IP público
{G}3.{W} Whois
{G}4.{W} Nmap
{G}5.{W} SQL Injection (Sqlmap)
{G}6.{W} Hash-Identifier
{G}7.{W} Gerar senha forte
{G}8.{W} Banner personalizado
{G}9.{W} Ativar/Desativar Matrix (cmatrix)
{G}0.{W} Sair
""")
        choice = input("Escolha uma opção: ").strip()

        if choice == '1':
            brute_force()
        elif choice == '2':
            show_ip()
        elif choice == '3':
            whois_lookup()
        elif choice == '4':
            nmap_scan()
        elif choice == '5':
            sqlmap_scan()
        elif choice == '6':
            hash_identifier()
        elif choice == '7':
            gen_password()
        elif choice == '8':
            custom_banner()
        elif choice == '9':
            toggle_cmatrix()
        elif choice == '0':
            print(f"{G}Saindo...{W}")
            sys.exit(0)
        else:
            print(f"{R}Opção inválida!{W}")
            time.sleep(1)

if __name__ == "__main__":
    main()
